# Platty Search for MEKO — English skill

Keep platty-search/SKILL.md and all eight references together.
Use the configured platty MCP connection and verify the default project is petshop-full. No access credential is included.

This archive is for reviewing or updating the skill files in an existing installation. For first installation, use platty-meko-demo.zip and its guide/en/platty-demo.html manual, or install the feat/demo branch.

https://github.com/paradigmshift-labs/platty/tree/feat/demo
