ALTER TABLE `project_llm_settings` ADD COLUMN `credential_env_name` text;
